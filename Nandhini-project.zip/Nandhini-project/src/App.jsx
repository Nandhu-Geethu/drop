import React from "react";
import Dropdown from "./Dropdown";
import "./App.css";

function App() {
  return (
    <div className="app">
      <h2>Disposition</h2>
      <Dropdown />
    </div>
  );
}

export default App;